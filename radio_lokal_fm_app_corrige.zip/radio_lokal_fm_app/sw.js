const CACHE='lokal-fm-v2';
const CORE=['./','./index.html','./manifest.json','./logo.jpg','./icon-192.png','./icon-512.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(u.origin===location.origin && e.request.method==='GET'){
    e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request)));
  }
});
